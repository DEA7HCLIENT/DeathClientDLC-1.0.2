package dev.deathclient.dlc;

import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.client.MinecraftClient;
import org.lwjgl.glfw.GLFW;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Properties;

/** Module keybinds: capture in the ClickGUI (middle click), toggle in game, persisted in the config folder. */
public final class Binds {
    private static final Path FILE = FabricLoader.getInstance().getConfigDir().resolve("deathclientdlc.properties");
    private static Module listening;

    private Binds() {}

    public static void listen(Module m) { listening = m; }
    public static Module listening() { return listening; }

    public static void load() {
        if (!Files.exists(FILE)) return;
        Properties props = new Properties();
        try (var in = Files.newInputStream(FILE)) {
            props.load(in);
        } catch (IOException e) {
            return;
        }
        for (Module m : ModuleManager.all()) {
            String v = props.getProperty("bind." + m.getName());
            if (v == null) continue;
            try { m.setKey(Integer.parseInt(v.trim())); } catch (NumberFormatException ignored) {}
        }
    }

    public static void save() {
        Properties props = new Properties();
        for (Module m : ModuleManager.all()) {
            if (m.getKey() != -1) props.setProperty("bind." + m.getName(), Integer.toString(m.getKey()));
        }
        try (var out = Files.newOutputStream(FILE)) {
            props.store(out, "DeathClientDLC keybinds (GLFW key codes)");
        } catch (IOException ignored) {}
    }

    /** Called every client tick, with or without a world. */
    public static void tick(MinecraftClient c) {
        long window = c.getWindow().getHandle();

        if (listening != null) {
            for (int k = GLFW.GLFW_KEY_SPACE; k <= GLFW.GLFW_KEY_LAST; k++) {
                if (GLFW.glfwGetKey(window, k) != GLFW.GLFW_PRESS) continue;
                if (k == GLFW.GLFW_KEY_ESCAPE) {
                    listening = null;                       // cancel
                    return;
                }
                listening.setKey(k == GLFW.GLFW_KEY_BACKSPACE || k == GLFW.GLFW_KEY_DELETE ? -1 : k);
                listening.keyDown = true;                   // don't toggle on the same press
                listening = null;
                save();
                return;
            }
            return;
        }

        boolean canToggle = c.player != null && c.currentScreen == null;
        for (Module m : ModuleManager.all()) {
            if (m.getKey() == -1) continue;
            boolean down = GLFW.glfwGetKey(window, m.getKey()) == GLFW.GLFW_PRESS;
            if (down && !m.keyDown && canToggle) m.toggle();
            m.keyDown = down;
        }
    }

    public static String name(int key) {
        if (key >= GLFW.GLFW_KEY_F1 && key <= GLFW.GLFW_KEY_F12) return "F" + (key - GLFW.GLFW_KEY_F1 + 1);
        switch (key) {
            case GLFW.GLFW_KEY_SPACE: return "Space";
            case GLFW.GLFW_KEY_TAB: return "Tab";
            case GLFW.GLFW_KEY_ENTER: return "Enter";
            case GLFW.GLFW_KEY_LEFT_SHIFT: return "LShift";
            case GLFW.GLFW_KEY_RIGHT_SHIFT: return "RShift";
            case GLFW.GLFW_KEY_LEFT_CONTROL: return "LCtrl";
            case GLFW.GLFW_KEY_RIGHT_CONTROL: return "RCtrl";
            case GLFW.GLFW_KEY_LEFT_ALT: return "LAlt";
            case GLFW.GLFW_KEY_RIGHT_ALT: return "RAlt";
            case GLFW.GLFW_KEY_UP: return "Up";
            case GLFW.GLFW_KEY_DOWN: return "Down";
            case GLFW.GLFW_KEY_LEFT: return "Left";
            case GLFW.GLFW_KEY_RIGHT: return "Right";
            case GLFW.GLFW_KEY_INSERT: return "Ins";
            case GLFW.GLFW_KEY_HOME: return "Home";
            case GLFW.GLFW_KEY_END: return "End";
            case GLFW.GLFW_KEY_PAGE_UP: return "PgUp";
            case GLFW.GLFW_KEY_PAGE_DOWN: return "PgDn";
            default:
                String n = GLFW.glfwGetKeyName(key, 0);
                return n != null ? n.toUpperCase() : "K" + key;
        }
    }
}
