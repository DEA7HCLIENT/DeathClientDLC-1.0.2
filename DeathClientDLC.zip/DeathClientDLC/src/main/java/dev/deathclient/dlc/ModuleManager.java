package dev.deathclient.dlc;

import net.minecraft.client.MinecraftClient;
import java.util.List;

public final class ModuleManager {
    private static final List<Module> MODULES = List.of(
            // Combat
            new KillAuraModule(),
            new TpAuraModule(),
            new CrystalAuraModule(),
            new AnchorAuraModule(),
            new CrystalOptimizationModule(),
            // Movement
            new SpeedModule(),
            new StrafeModule(),
            new FlyModule("Fly", false),
            new NoClipModule(),
            new FlyModule("NoClip Fly", true),
            new SpinModule(),
            // Render
            new PendingModule("ESP", Category.RENDER),
            new GlowEspModule(),
            new PendingModule("Charms", Category.RENDER),
            new PendingModule("No Render", Category.RENDER),
            new PendingModule("View Model", Category.RENDER),
            new SwingAnimationModule(),
            new VisualSpinModule(),
            // Visuals
            new TargetEspModule(),
            new JumpCircleModule(),
            new PendingModule("Glass Hand", Category.VISUALS),
            new TrailsModule(),
            new FullbrightModule(),
            new FovModule(),
            // Misc
            new OptimizationModule());

    private ModuleManager() {}

    public static List<Module> all() { return MODULES; }

    public static List<Module> of(Category c) {
        return MODULES.stream().filter(m -> m.getCategory() == c).toList();
    }

    public static <T extends Module> T get(Class<T> type) {
        for (Module m : MODULES) if (type.isInstance(m)) return type.cast(m);
        return null;
    }

    public static void tick(MinecraftClient client) {
        if (client.player == null || client.world == null) return;
        for (Module m : MODULES) if (m.isEnabled()) m.onTick(client);
    }
}
