package dev.deathclient.dlc;

import net.minecraft.client.MinecraftClient;

/** Spins only the rendered body and head (visible in third person); the camera stays put. */
public class VisualSpinModule extends Module {
    public final NumberSetting speed = add(new NumberSetting("Speed", 30, 5, 90, 5));
    private float yaw;

    public VisualSpinModule() { super("Visual Spin", Category.RENDER); }

    @Override
    protected void onEnable() {
        MinecraftClient c = MinecraftClient.getInstance();
        if (c.player != null) yaw = c.player.getYaw();
    }

    @Override
    public void onTick(MinecraftClient c) {
        yaw += (float) speed.get();
        c.player.bodyYaw = yaw;
        c.player.headYaw = yaw;
    }
}
