package dev.deathclient.dlc;

import net.minecraft.client.MinecraftClient;
import net.minecraft.particle.ParticleEffect;
import net.minecraft.particle.ParticleTypes;
import java.util.List;

/** Client-side particle effects shared by the visual modules. */
final class Fx {
    /** Style 1..5: End rod, Flame, Soul flame, Crit, Happy villager. */
    private static final List<ParticleEffect> STYLES = List.of(
            ParticleTypes.END_ROD, ParticleTypes.FLAME, ParticleTypes.SOUL_FIRE_FLAME,
            ParticleTypes.CRIT, ParticleTypes.HAPPY_VILLAGER);

    private Fx() {}

    static NumberSetting styleSetting() { return new NumberSetting("Style", 1, 1, STYLES.size(), 1); }

    static ParticleEffect style(NumberSetting s) {
        int i = Math.max(1, Math.min(STYLES.size(), (int) s.get()));
        return STYLES.get(i - 1);
    }

    static void spawn(MinecraftClient c, ParticleEffect e, double x, double y, double z) {
        c.particleManager.addParticle(e, x, y, z, 0, 0, 0);
    }

    static void ring(MinecraftClient c, ParticleEffect e, double cx, double cy, double cz, double radius, int points) {
        for (int i = 0; i < points; i++) {
            double a = 2 * Math.PI * i / points;
            spawn(c, e, cx + Math.cos(a) * radius, cy, cz + Math.sin(a) * radius);
        }
    }
}
