package dev.deathclient.dlc;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.Hand;
import net.minecraft.util.math.Vec3d;

/** Attacks the nearest valid target in range once the weapon cooldown is full. */
public class KillAuraModule extends Module {
    public final NumberSetting range = add(new NumberSetting("Range", 3.0, 1.0, 6.0, 0.1));
    public final BoolSetting playersOnly = add(new BoolSetting("Players only", true));
    public final BoolSetting rotate = add(new BoolSetting("Rotate", true));

    public KillAuraModule() { super("KillAura", Category.COMBAT); }

    @Override
    public void onTick(MinecraftClient c) {
        ClientPlayerEntity p = c.player;
        if (p.getAttackCooldownProgress(0.5f) < 0.95f) return;
        LivingEntity target = findTarget(c, p);
        if (target == null) return;
        if (rotate.get()) face(p, target);
        c.interactionManager.attackEntity(p, target);
        p.swingHand(Hand.MAIN_HAND);
    }

    private LivingEntity findTarget(MinecraftClient c, ClientPlayerEntity p) {
        LivingEntity best = null;
        double bestD = range.get();
        for (Entity e : c.world.getEntities()) {
            if (!(e instanceof LivingEntity le) || e == p || !le.isAlive() || le.isSpectator()) continue;
            if (playersOnly.get() && !(le instanceof PlayerEntity)) continue;
            double d = p.distanceTo(le);
            if (d <= bestD) { bestD = d; best = le; }
        }
        return best;
    }

    private static void face(ClientPlayerEntity p, LivingEntity target) {
        Vec3d eye = p.getEyePos();
        Vec3d t = target.getBoundingBox().getCenter();
        double dx = t.x - eye.x, dy = t.y - eye.y, dz = t.z - eye.z;
        double h = Math.sqrt(dx * dx + dz * dz);
        p.setYaw((float) (Math.toDegrees(Math.atan2(dz, dx)) - 90.0));
        p.setPitch((float) -Math.toDegrees(Math.atan2(dy, h)));
    }
}
