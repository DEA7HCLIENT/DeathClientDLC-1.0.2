package dev.deathclient.dlc;

import net.minecraft.client.gui.Click;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.text.Text;
import java.util.ArrayList;
import java.util.List;

/**
 * Panel-per-category ClickGUI with rounded panel corners.
 * LMB header: drag. RMB header: collapse. LMB module: toggle. RMB module: settings.
 * LMB bool setting: toggle. LMB/drag number setting: slider.
 */
public class ClickGuiScreen extends Screen {
    private static final int W = 110, HEAD = 18, ROW = 16, SROW = 16, GAP = 8;
    /** Corner radius in GUI pixels. */
    private static final int R = 4;
    private static final int PAD = 6;


    private static final int BG = 0xE0141414, SETTING_BG = 0xE01E1E1E, HEADER = 0xFF1E1E1E;
    private static final int ACCENT = 0xFFB3202A, TRACK = 0xFF333333, HOVER = 0x30FFFFFF;
    private static final int WHITE = 0xFFFFFFFF, MUTED = 0xFFAAAAAA;

    private static final class Panel {
        final Category cat;
        int x, y;
        boolean open = true;
        Panel(Category cat, int x, int y) { this.cat = cat; this.x = x; this.y = y; }
    }

    /** Static so panel positions survive reopening the screen. */
    private static List<Panel> panels;
    private static boolean placed;

    private Panel dragPanel;
    private double dragDX, dragDY;
    private NumberSetting dragSetting;
    private Panel dragSettingPanel;

    public ClickGuiScreen() {
        super(Text.literal("DeathClientDLC"));
        if (panels == null) {
            panels = new ArrayList<>();
            for (Category c : Category.values()) {
                if (ModuleManager.of(c).isEmpty()) continue;
                panels.add(new Panel(c, 0, 0));
            }
        }
    }

    @Override
    protected void init() {
        if (placed) return;
        placed = true;
        int x = 10, y = 62, rowH = 0;
        for (Panel p : panels) {
            if (x + W > width - 4 && x > 10) { x = 10; y += rowH + GAP; rowH = 0; }
            p.x = x;
            p.y = y;
            rowH = Math.max(rowH, panelHeight(p));
            x += W + GAP;
        }
    }

    private static boolean in(double mx, double my, int x, int y, int w, int h) {
        return mx >= x && mx < x + w && my >= y && my < y + h;
    }

    private static int inset(int r, int i) {
        double dy = r - i - 0.5;
        return (int) Math.round(r - Math.sqrt(r * r - dy * dy));
    }

    /** Filled rect with optional rounded top and/or bottom corners (one scanline per corner row). */
    static void rect(DrawContext ctx, int x, int y, int w, int h, int color, boolean top, boolean bottom) {
        int r = Math.min(R, h / 2);
        int t = top ? r : 0, b = bottom ? r : 0;
        for (int i = 0; i < t; i++) {
            int in = inset(r, i);
            ctx.fill(x + in, y + i, x + w - in, y + i + 1, color);
        }
        for (int i = 0; i < b; i++) {
            int in = inset(r, i);
            ctx.fill(x + in, y + h - 1 - i, x + w - in, y + h - i, color);
        }
        ctx.fill(x, y + t, x + w, y + h - b, color);
    }

    private int panelHeight(Panel p) {
        int h = HEAD;
        if (!p.open) return h;
        for (Module m : ModuleManager.of(p.cat)) {
            h += ROW;
            if (m.expanded) h += SROW * m.getSettings().size();
        }
        return h;
    }

    private void text(DrawContext ctx, String s, int x, int y, int color) {
        ctx.drawTextWithShadow(textRenderer, s, x, y, color);
    }

    @Override
    public void renderBackground(DrawContext ctx, int mx, int my, float delta) {
        // In a world: draw nothing (no blur, no dimming) so the game stays visible.
        if (client != null && client.world != null) return;
        Ui.drawBackground(ctx, width, height);
    }

    @Override
    public void render(DrawContext ctx, int mx, int my, float delta) {
        super.render(ctx, mx, my, delta);
        Ui.drawTitle(ctx, width);
        String hint = "LMB toggle   RMB settings   MMB bind";
        text(ctx, hint, (width - textRenderer.getWidth(hint)) / 2, height - 14, MUTED);
        for (Panel p : panels) renderPanel(ctx, p, mx, my);
    }

    private void renderPanel(DrawContext ctx, Panel p, int mx, int my) {
        rect(ctx, p.x, p.y, W, HEAD, HEADER, true, !p.open);
        text(ctx, p.cat.label, p.x + PAD, p.y + 5, WHITE);
        text(ctx, p.open ? "-" : "+", p.x + W - 12, p.y + 5, MUTED);
        if (!p.open) return;
        ctx.fill(p.x, p.y + HEAD - 1, p.x + W, p.y + HEAD, ACCENT);

        int bottom = p.y + panelHeight(p);
        int y = p.y + HEAD;
        for (Module m : ModuleManager.of(p.cat)) {
            boolean last = y + ROW == bottom;
            rect(ctx, p.x, y, W, ROW, m.isEnabled() ? ACCENT : BG, false, last);
            if (in(mx, my, p.x, y, W, ROW)) rect(ctx, p.x, y, W, ROW, HOVER, false, last);
            text(ctx, m.getName(), p.x + PAD, y + 4, WHITE);
            if (!m.getSettings().isEmpty()) text(ctx, m.expanded ? "v" : ">", p.x + W - 12, y + 4, MUTED);
            String bind = Binds.listening() == m ? "..." : (m.getKey() != -1 ? "[" + Binds.name(m.getKey()) + "]" : null);
            if (bind != null) text(ctx, bind, p.x + W - 16 - textRenderer.getWidth(bind), y + 4, MUTED);
            y += ROW;

            if (!m.expanded) continue;
            for (Setting s : m.getSettings()) {
                last = y + SROW == bottom;
                rect(ctx, p.x, y, W, SROW, SETTING_BG, false, last);
                if (s instanceof BoolSetting b) {
                    text(ctx, b.name, p.x + PAD + 2, y + 4, WHITE);
                    String v = b.get() ? "ON" : "OFF";
                    text(ctx, v, p.x + W - PAD - textRenderer.getWidth(v), y + 4, b.get() ? ACCENT : MUTED);
                } else if (s instanceof NumberSetting n) {
                    text(ctx, n.name, p.x + PAD + 2, y + 2, WHITE);
                    String v = String.format(n.step < 0.1 ? "%.2f" : "%.1f", n.get());
                    text(ctx, v, p.x + W - PAD - textRenderer.getWidth(v), y + 2, MUTED);
                    int trackW = W - 2 * PAD;
                    int fillW = (int) (trackW * (n.get() - n.min) / (n.max - n.min));
                    ctx.fill(p.x + PAD, y + SROW - 5, p.x + PAD + trackW, y + SROW - 3, TRACK);
                    ctx.fill(p.x + PAD, y + SROW - 5, p.x + PAD + fillW, y + SROW - 3, ACCENT);
                }
                y += SROW;
            }
        }
    }

    private boolean clickPanel(Panel p, double mx, double my, int btn) {
        if (in(mx, my, p.x, p.y, W, HEAD)) {
            if (btn == 0) { dragPanel = p; dragDX = mx - p.x; dragDY = my - p.y; }
            else if (btn == 1) p.open = !p.open;
            return true;
        }
        if (!p.open) return false;

        int y = p.y + HEAD;
        for (Module m : ModuleManager.of(p.cat)) {
            if (in(mx, my, p.x, y, W, ROW)) {
                if (btn == 0) m.toggle();
                else if (btn == 1 && !m.getSettings().isEmpty()) m.expanded = !m.expanded;
                else if (btn == 2) Binds.listen(m);
                return true;
            }
            y += ROW;
            if (!m.expanded) continue;
            for (Setting s : m.getSettings()) {
                if (in(mx, my, p.x, y, W, SROW)) {
                    if (btn == 0) {
                        if (s instanceof BoolSetting b) b.toggle();
                        else if (s instanceof NumberSetting n) {
                            dragSetting = n;
                            dragSettingPanel = p;
                            updateSlider(mx);
                        }
                    }
                    return true;
                }
                y += SROW;
            }
        }
        return false;
    }

    private void updateSlider(double mx) {
        double t = Math.max(0, Math.min(1, (mx - (dragSettingPanel.x + PAD)) / (W - 2 * PAD)));
        dragSetting.set(dragSetting.min + t * (dragSetting.max - dragSetting.min));
    }

    @Override
    public boolean mouseClicked(Click click, boolean doubled) {
        for (int i = panels.size() - 1; i >= 0; i--) {
            Panel p = panels.get(i);
            if (clickPanel(p, click.x(), click.y(), click.button())) {
                panels.remove(i);
                panels.add(p);
                return true;
            }
        }
        return super.mouseClicked(click, doubled);
    }

    @Override
    public boolean mouseDragged(Click click, double offsetX, double offsetY) {
        if (dragPanel != null) {
            dragPanel.x = (int) (click.x() - dragDX);
            dragPanel.y = (int) (click.y() - dragDY);
            return true;
        }
        if (dragSetting != null) {
            updateSlider(click.x());
            return true;
        }
        return super.mouseDragged(click, offsetX, offsetY);
    }

    @Override
    public boolean mouseReleased(Click click) {
        dragPanel = null;
        dragSetting = null;
        dragSettingPanel = null;
        return super.mouseReleased(click);
    }

    @Override
    public boolean shouldPause() { return false; }
}
